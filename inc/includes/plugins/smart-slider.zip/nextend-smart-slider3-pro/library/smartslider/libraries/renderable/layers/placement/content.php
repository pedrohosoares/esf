<?php

class  N2SSSlidePlacementContent extends N2SSSlidePlacement {

    public function attributes(&$attributes) {

        $attributes['data-pm'] = 'content';
    }
}